import 'package:application/controllers/account.dart';
import 'package:flutter/material.dart';

import 'views/admission/widgets/loan_card.dart';


class LabPage extends StatelessWidget {
  const LabPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        // child:LoanCard(),
      ),
    );
  }
}
